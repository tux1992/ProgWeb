<main>
	<h1>Algo no ha ido bien</h1>
	<p>Vuelve a intentarlo con otra opción </p>
</main>