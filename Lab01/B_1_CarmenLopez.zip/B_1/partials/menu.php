<nav>
	<ul>
		<li>
			<a href="?action=home">Home</a>
		</li>
		<li>
			<a href="?action=form_register">Registre</a>
		</li>
		<li>
			<a href="?action=list">Llistar</a>
		</li>

		<li>
			<a href="?action=modify">Modificar</a>
		</li>
		<li>
			<a href="../B_1/holaMundo.php">HolaMundo</a>
		</li>
		<li>
			<a href="?action=qui_som">Qui som?</a>
		</li>
		<li>
			<a href="?action=tablas">Cursos i activitats</a>
		</li>
		<li>
			<a href="?action=afegirCurs">Afegir Curs</a>
		</li>
		<li>
		<li>
			<a href="?action=galeria">Galeria</a>
		</li>
		<li>
			<a href="?action=privacitat">Privacitat</a>
		</li>
	</ul>
</nav>
