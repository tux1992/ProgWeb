<main>
    <h1>Llistat de Cursos</h1>
    <table>
        <tr>
            <th>Codi</th>
            <th>Descripció</th>
            <th>Nombre Màxim d'Alumnes</th>
            <th>Places Vacants</th>
            <th>Preu Trimestre</th>
        </tr>
        <tr>
            <td>101</td>
            <td>Laboratori  de Robòtica</td>
            <td>15</td>
            <td>3</td>
            <td>1.000€</td>
        </tr>
        <tr>
            <td>102</td>
            <td>Natació Sincronitzada</td>
            <td>20</td>
            <td>5</td>
            <td>1.200€</td>
        </tr>
        <tr>
            <td>103</td>
            <td>Classes de Pàdel</td>
            <td>10</td>
            <td>2</td>
            <td>1.500€</td>
        </tr>
        <tr>
            <td>104</td>
            <td>Teatre</td>
            <td>18</td>
            <td>4</td>
            <td>1.100€</td>
        </tr>
        <tr>
            <td>105</td>
            <td>Música</td>
            <td>12</td>
            <td>2</td>
            <td>1.300€</td>
        </tr>
    </table>
</main>
