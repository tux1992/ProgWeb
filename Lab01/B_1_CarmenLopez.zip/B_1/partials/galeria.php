<main>
    <div class="galeria">
        <div class="item">
            <img src="media/galeria/esgrima.jpg" alt="Imatge de la sala d'esgrima del Col·legi Sensal, on es pot apreciar com practiquen els alumnes.">
            <p>Esgrima</p>
        </div>
        <div class="item">
            <img src="media/galeria/golf.jpg" alt="Imatge del camp de golf, està molt verd i s'aprecien unes persones muntades en dos carts de golf.">
            <p>Camp de golf</p>
        </div>
        <div class="item">
            <img src="media/galeria/tenis.jpg" alt="Pistes de tenis que formen part de les instal·lacions del centre educatiu.">
            <p>Pistes de tenis</p>
        </div>
        <div class="item">
            <img src="media/galeria/futbol.jpg" alt="En aquesta foto apareix el campt de futbol del Col·legi Sensal.">
            <p>Camp de futbol</p>
        </div>
        <div class="item">
            <img src="media/galeria/labrobotica.jpg" alt="Laboratori de robòtica del centre.">
            <p>Laboratori de robotica</p>
        </div>
        <div class="item">
            <img src="media/galeria/biblioteca.avif" alt="Biblioteca de varies plantes.">
            <p>Biblioteca</p>
        </div>
        <div class="item">
            <img src="media/galeria/obrasRugby.jpg" alt="Obres per a construir el camp de rugbi.">
            <p>Obres del camp de rugbi</p>
        </div>
        <div class="item">
            <img src="media/galeria/basket.jpg" alt="Pistes interiors de basket.">
            <p>Camp de basket</p>
        </div>
        <div class="item">
            <img src="media/galeria/invernadero.png" alt="Invernader del centre.">
            <p>Invernadero</p>
        </div>
        <div class="item">
            <img src="media/galeria/salaestudio.jpg" alt="Una de les sales d'estudi del Col·legi Sensal.">
            <p>Sala d'estudi</p>
        </div>
        <div class="item">
            <img src="media/galeria/padel.jpg" alt="Pistes de padel del Col·legi Sensal">
            <p>Pistes de pàdel</p>
        </div>
        <div class="item">
            <img src="media/galeria/piscina.jpg" alt="Piscina olímpica.">
            <p>Piscina</p>
        </div>
      

    </div>
</main>

