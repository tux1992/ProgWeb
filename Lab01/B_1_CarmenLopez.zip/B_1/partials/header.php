<!DOCTYPE html>
<html lang="es">

    <head>
	    <meta charset="UTF-8">
	    <title>Portal Pruebas </title>
	    <meta name="Author" content="AlumnoXXX">
	    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
	    <link rel="icon" type="image/ico" href="./media/icon.png">

    </head>


    <body>
	    <header>
		    <img src="./media/logoo.png" id="logo" alt="logo" />
		    <h1 id="eslogan"> Col·legi Sensal</h1>
	    </header>
