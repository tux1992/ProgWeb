<aside class="news-section">
    <p>Les noticies del nostre barri</p>
    <ul>
        <li>
            <iframe src="https://acortar.link/5aHmul" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/MwtnFj" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/oCdr67" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/KkBLK7" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/0rMhor" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/6bsheX" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/FoSgbB" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/Dr8Gf9" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/2a4x8e" width="200" height="150"></iframe>
        </li>     
        <li>
            <iframe src="https://acortar.link/Czisj7" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/EWnWZu" width="200" height="150"></iframe>
        </li>
        <li>
            <iframe src="https://acortar.link/KBgWMC" width="200" height="150"></iframe>
        </li>
    </ul>
</aside>
