        <footer>
	        <img src="https://licensebuttons.net/l/by-sa/3.0/88x31.png" alt="licencia" />
	        <time class="time" datetime="2023-10-16">2023</time><br/>
	        <address>
		        <h2 class="izq"> Written by
			        <a href="mailto:al318118@uji.es" rev="author">Carmen López</a>.</h2>
		        <p class="der"> Visit us at:Col·legi Sensal, Carrer riu Pisuerga 41, Castelló</p>
	        </address>
        </footer>
    </body>

</html>
